-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 12-11-2015 a las 19:25:03
-- Versión del servidor: 5.5.24-log
-- Versión de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `sisgen`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `actualizaInsumo`(id int ,codigo varchar(50),nombre varchar(50),detalle varchar(200),costo int)
BEGIN
	declare resultado varchar(5);
    if id!="" then
			update insumos set INS_CODIGO=codigo,INS_NBINSUMO=nombre,
            INS_DETALLE=detalle,INS_COSTOINSUMO=costo
            where INS_IDINSUMO=id;
                set resultado = "ok";
                select resultado;
	end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `actualizaMarca`(id int,nombre varchar(100),observacion varchar(100))
BEGIN
	update marca set MAR_NBMARCA = nombre, MAR_OBSERVACION=observacion where
    MAR_IDMARCA = id;
    select "ok";
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `consultaEquipamiento`(idx int)
BEGIN
declare resultado varchar(50);
declare id int;
	if exists (select taller.EQ_IDEQUIPO  FROM taller where taller.TA_IDTALLER = idx 
	and (taller.EQ_IDEQUIPO <> NULL or taller.EQ_IDEQUIPO <> '')) then
		set resultado = 'equipo';
		select resultado,id;
	
	else if exists (select taller.IM_IDIMPRESION FROM taller where taller.TA_IDTALLER = idx  and
	(taller.IM_IDIMPRESION <> NULL or taller.IM_IDIMPRESION <> '')) then
			set resultado = 'impresion';
		
		select resultado,id;	
	
	else if exists(select taller.TA_IDRED FROM taller where taller.TA_IDTALLER = idx and
			(taller.TA_IDRED <> NULL or taller.TA_IDRED <> '')) then
			set resultado = 'red';
		
		select resultado,id as 'total';	 
	end if;
	end if;
	end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `consultaExistentePendiente`(idEq int,idIm int, idRed int)
BEGIN
if exists(
select taller.TA_IDTALLER FROM taller WHERE
(taller.EQ_IDEQUIPO = idEq
OR
taller.IM_IDIMPRESION = idIm
OR
taller.TA_IDRED = idRed
)
AND
taller.TA_MOTIVO = 'orden'
and
taller.TA_ESTADO = 'pendiente') then
	select "si";
else 
	select "no";

end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `consultaSO`(id int)
begin
declare resultado int;
set resultado = 0;
	if  not exists(select software.* from software where (
software.EQ_IDEQUIPO= id and software.SOFT_TIPOSOFTW ="sistema operativo" and software.SOFT_ACTIVADO = "activo")) then
			set resultado = 1;
			select resultado;
	else 
			set resultado = 2;
			select resultado;
	end if;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `crearLog`(ipx varchar(60),
observacion varchar(100),
idusuario int)
BEGIN
	insert into log(log_fechalog,log_iplog,log_observacion,log_idusuario) values
        (NOW(),ipx,observacion,idusuario);
select 'ok';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `crearPerfil2`(
nombre varchar(60),apellido varchar(60),
direccion varchar(100),
rutpers varchar(40),
idperfil int,
nbusuario varchar(45),
correo varchar(100),
claveusu varchar(50),
observacion varchar(45))
BEGIN
declare ultimoid int;
	
		insert into persona(pers_nbpersona,
pers_apppersona,
pers_dirpersona,pers_rutpersona) values(nombre,apellido,direccion,
rutpers);
	set ultimoid = last_insert_id();
	insert into usuario(usu_nbusuario,usu_correousuario,
usu_passusuario,usu_fcreacion,usu_observacion,
usu_idpersona,usu_idperfil) 
values(
nbusuario,correo,claveusu,now(),observacion,ultimoid,idperfil);
	select 'ok';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `devuelveDetalle`(idx int)
BEGIN
select 
insumos.INS_IDINSUMO,
insumos.INS_CODIGO,
insumos.INS_NBINSUMO,
insumos.INS_DETALLE,
insumos.INS_COSTOINSUMO,
detalle.DET_CANTIDAD
from 
insumos,detalle
where
insumos.INS_IDINSUMO = detalle.DET_IDINSUMO
and
detalle.TA_IDTALLER = idx;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `devuelveHistorico`(idx int)
BEGIN
	select usuario.usu_nbusuario,taller.* from usuario,taller where 
usuario.usu_idusuario = taller.TA_IDUSUARIO
AND
taller.TA_IDTALLER = idx;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `devuelvePendiente`(id int )
BEGIN
	select  * from taller
where taller.TA_IDTALLER=id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `devuelvePendientes`(id int,tipo varchar(50))
BEGIN
select 
equipo.EQ_SERIEEQUIPO,
usuario.usu_nbusuario,
taller.TA_IDTALLER,
taller.TA_IDUSUARIO,
taller.TA_FCREACION,
taller.TA_ESTADO,
taller.TA_MOTIVO 
FROM
equipo,usuario,taller
where(
equipo.EQ_IDEQUIPO =taller.EQ_IDEQUIPO
and
usuario.usu_idusuario = taller.TA_IDUSUARIO
)
and taller.TA_ESTADO NOT IN(SELECT TALLER.TA_ESTADO FROM 
TALLER WHERE TALLER.TA_ESTADO = 'finalizado') and
taller.TA_IDUSUARIO = id and taller.TA_MOTIVO=tipo
ORDER BY taller.TA_FCREACION ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `devuelveSep`(id int)
BEGIN
select TA_IDTALLER,TA_IDEQUIPO,TA_IDUSUARIO,TA_FCREACION,TA_FEJECUCION,TA_MOTIVO,TA_ESTADO from taller where 
taller.TA_IDTALLER = id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `devuelveUsuarios`()
BEGIN
	select * from usuario;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertaDetalle`(id int,idx int,cant int)
BEGIN
	insert into detalle(TA_IDTALLER,DET_IDINSUMO,DET_CANTIDAD)
VALUES(id,idx,cant);
SELECT "ok";
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertaInsumo`(codigo varchar(50),nombre varchar(50),detalle varchar(200),costo int)
begin
	declare resultado varchar(5);
			insert into insumos(INS_CODIGO,INS_NBINSUMO,INS_DETALLE,INS_FCREACION,INS_COSTOINSUMO)
				VALUES(codigo,nombre,detalle,now(),costo);
                set resultado = "ok";
                select resultado;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertaMarca`(marca varchar(100),observacion varchar(100))
BEGIN
	insert into marca (MAR_NBMARCA,MAR_OBSERVACION,MAR_FCREACION) 
    values(marca,observacion,now());
    select "ok";
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertaSep`(
idEq int, idUsuario int,
descripcion varchar(200), motivo varchar(50)
,estado varchar(50)
)
BEGIN
	insert into taller
(taller.EQ_IDEQUIPO,taller.TA_IDUSUARIO,
taller.TA_FCREACION,
taller.TA_DESCTALLER,
taller.TA_MOTIVO,
taller.TA_ESTADO)
VALUES (
idEq,idUsuario,now(),descripcion,motivo,estado);
	select last_insert_id();
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertaTaller`(idequipo int, 
idimpresion int,idred int,
idusuario int,descripcion varchar(200),motivo varchar(50),
defecto varchar(100),diagnostico varchar(200),
estado varchar(50))
BEGIN
if exists(select taller.TA_IDTALLER FROM taller WHERE
(taller.EQ_IDEQUIPO = idequipo
OR
taller.IM_IDIMPRESION = idimpresion
OR
taller.TA_IDRED = idred
)
AND
taller.TA_MOTIVO = 'informe'
and
taller.TA_ESTADO = 'pendiente') then
select "no";
else
	insert into taller(EQ_IDEQUIPO,IM_IDIMPRESION,TA_IDRED,
TA_IDUSUARIO,TA_FCREACION,TA_FEJECUCION,TA_DESCTALLER,TA_MOTIVO,
TA_DEFECTO,TA_DIAGNOSTICO,TA_ESTADO)
VALUES(idequipo,idimpresion,idred,idusuario,now(),'0000-00-00',
descripcion,motivo,defecto,diagnostico,estado);
select "ok";
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insertaTaller2`(idequipo int, 
idimpresion int,idred int,
idusuario int,descripcion varchar(200),motivo varchar(50),
defecto varchar(100),diagnostico varchar(200),
estado varchar(50),opcion varchar(50))
BEGIN
declare resultado varchar(50);
set resultado = '';


	if opcion = 'equipo' then
		update equipo set equipo.EQ_ESTADO='reparacion' WHERE
	equipo.EQ_IDEQUIPO = idequipo;
	set resultado = 'ok';
	end if;

	if opcion = 'impresora' then
		update impresion set
 impresion.IM_ESTADOIMP ='reparacion' WHERE
	impresion.IM_IDIMPRESION = idimpresion;
	set resultado = 'ok';
	end if;

	if opcion = 'red' then
		update red set red.RED_ESTADO='reparacion' WHERE
	red.RED_IDRED = idred;
	set resultado = 'ok';
	end if;

if resultado = 'ok' then
	insert into taller(EQ_IDEQUIPO,IM_IDIMPRESION,TA_IDRED,
TA_IDUSUARIO,TA_FCREACION,TA_FEJECUCION,TA_DESCTALLER,TA_MOTIVO,
TA_DEFECTO,TA_DIAGNOSTICO,TA_ESTADO)
VALUES(idequipo,idimpresion,idred,idusuario,now(),'0000-00-00',
descripcion,motivo,defecto,diagnostico,estado);
select last_insert_id();
end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `obtieneMarca`()
BEGIN
	select marca.MAR_IDMARCA,marca.MAR_NBMARCA from marca;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `recuperaInsumo`(id int)
BEGIN

    if id !="" then
			select * from insumos where insumos.INS_IDINSUMO=id;
    end if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `reporteBusquedaEquipo`( serie varchar(100))
BEGIN
	select * from equipo where equipo.EQ_SERIEEQUIPO=serie;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `reporteBusquedaImpresion`(campo varchar(100))
BEGIN
select * from impresion where
impresion.IM_SERIEIMPRESION = campo;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `reporteEquiposSofware`()
BEGIN
	SELECT equipo.EQ_IDEQUIPO,equipo.EQ_SERIEEQUIPO,equipo.EQ_MODELO,software.SOF_NBSOFTW,software.SOFT_TIPOSOFTW,licencia.LIC_NROLICENCIA
	FROM
	equipo,software,licencia
	where
	equipo.EQ_IDEQUIPO = software.SOF_IDSOFTW
	AND
	software.SOF_IDSOFTW = licencia.SOF_IDSOFTW;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `reporteImpresora`()
BEGIN
	select IM_SERIEIMPRESION, IM_MODELO,IM_TIPOIMPRESION,MAR_NBMARCA,TIP_NBTIPO
FROM
impresion,marca, tipo
where
impresion.IM_MARCA = marca.MAR_IDMARCA
AND
impresion.TIP_IDTIPO = tipo.TIP_IDTIPO;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `reporteObtenLog`()
BEGIN
	select log_fechalog,log_iplog,log_observacion,usuario.usu_nbusuario,persona.pers_nbpersona,persona.pers_apppersona,persona.pers_rutpersona 
from log, usuario,persona
where
log.log_idusuario = usuario.usu_idusuario
and
usuario.usu_idpersona = persona.pers_idpersona
;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `reporteTecnicoEquipo`()
BEGIN
select 
equipo.EQ_SERIEEQUIPO,equipo.EQ_MODELO,equipo.EQ_PROCESADOR,equipo.EQ_RAM,equipo.EQ_DISCO,equipo.EQ_COSTO,periferico.PER_SERIEPERIFERICO,tipo.TIP_NBTIPO
FROM
equipo,periferico,tipo
where
equipo.EQ_IDEQUIPO = periferico.EQ_IDEQUIPO
and
periferico.TIP_IDTIPO = tipo.TIP_IDTIPO
order
by 
equipo.EQ_IDEQUIPO asc;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `reporteTecnicoImpresora`()
BEGIN
select IM_IDIMPRESION,IM_SERIEIMPRESION, IM_MODELO,IM_TIPOIMPRESION,IM_ESTADOIMP,IM_FCREACION,
MARCA.MAR_NBMARCA FROM
IMPRESION,MARCA
WHERE
impresion.IM_MARCA = marca.MAR_IDMARCA
order
by 
impresion.im_idimpresion asc;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `reporteTecnicoRed`()
BEGIN
select RED_MODELO,
RED_SERIERED,RED_MACEQUIPO,RED_NROBOCAS,
RED_IPINICIAL,RED_MASCARA,
RED_PTAENLACE,
TIP_NBTIPO, MAR_NBMARCA
FROM
red, tipo, marca
where
red.TIP_IDTIPO = tipo.TIP_IDTIPO
and
red.RED_MARCAEQUIPO = marca.MAR_IDMARCA
order by 
red.RED_IDRED asc;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `reporteUbicacionEquipo`()
BEGIN
select 
equipo.EQ_SERIEEQUIPO,equipo.EQ_MODELO,ubicacion.*
from equipo,ubicacion
where equipo.UB_IDUBICACION = ubicacion.UB_IDUBICACION
ORDER BY 
equipo.EQ_IDEQUIPO ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `reporteUbicacionRed`()
BEGIN
select RED_MODELO,
RED_SERIERED,RED_MACEQUIPO,UB_NROSALA,UB_PISOSALA,UB_TIPOSALA
FROM
red, ubicacion
where
red.UB_IDUBICACION = ubicacion.UB_IDUBICACION
order by 
red.RED_IDRED asc;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectInsumo`()
BEGIN
	select * from insumos;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectMarca`(id int)
BEGIN
	SELECT * FROM marca WHERE MAR_IDMARCA = id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectPerfilAdmin`()
BEGIN
	select perf_idperfil, perf_nbperfil,perf_modulo
from
perfil
where
(perf_nbperfil = 'administrador' or perf_nbperfil='visualizador')and
perf_modulo='inventario';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectPersona`()
BEGIN
	select * from persona;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectSolicitud`(desde datetime, hasta datetime)
BEGIN
	select taller.TA_IDTALLER,
taller.TA_DESCTALLER,taller.TA_DEFECTO,taller.TA_DIAGNOSTICO,taller.TA_MOTIVO,taller.TA_FCREACION,taller.TA_FEJECUCION
FROM TALLER
WHERE
taller.TA_FCREACION BETWEEN desde AND hasta
AND
taller.TA_MOTIVO='orden'
ORDER BY taller.TA_FCREACION ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selectUsuario`(usuario varchar(45), clave varchar(50))
BEGIN

		select usuario.usu_idusuario, usuario.usu_nbusuario, usuario.usu_idpersona, 
  perfil.perf_nbperfil, perfil.perf_modulo from usuario,perfil where usuario.usu_nbusuario =usuario
  and usuario.usu_passusuario = clave
and usuario.usu_idperfil = perfil.perf_idperfil
;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle`
--
-- Creación: 28-10-2015 a las 18:34:53
--

CREATE TABLE IF NOT EXISTS `detalle` (
  `DET_IDDETALLE` int(11) NOT NULL AUTO_INCREMENT,
  `TA_IDTALLER` int(11) DEFAULT NULL,
  `DET_IDINSUMO` int(11) DEFAULT NULL,
  `DET_CANTIDAD` int(11) NOT NULL,
  PRIMARY KEY (`DET_IDDETALLE`),
  KEY `detalle_taller` (`TA_IDTALLER`),
  KEY `detalle_insumo` (`DET_IDINSUMO`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `detalle`
--

INSERT INTO `detalle` (`DET_IDDETALLE`, `TA_IDTALLER`, `DET_IDINSUMO`, `DET_CANTIDAD`) VALUES
(1, 1, 1, 1),
(2, 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipo`
--
-- Creación: 28-10-2015 a las 18:34:53
--

CREATE TABLE IF NOT EXISTS `equipo` (
  `EQ_IDEQUIPO` int(11) NOT NULL AUTO_INCREMENT,
  `UB_IDUBICACION` int(11) DEFAULT NULL,
  `EQ_IDTIPO` int(11) NOT NULL,
  `EQ_NROEQUIPO` smallint(6) DEFAULT NULL,
  `EQ_SERIEEQUIPO` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `EQ_MARCA` int(11) DEFAULT NULL,
  `EQ_MODELO` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `EQ_RAM` int(11) DEFAULT NULL,
  `EQ_DISCO` int(11) DEFAULT NULL,
  `EQ_MAC` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `EQ_IP` varchar(60) COLLATE utf8_spanish_ci DEFAULT NULL,
  `EQ_PTAENLACE` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `EQ_MASCARA` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `EQ_PROCESADOR` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `EQ_ESTADO` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `EQ_FINGRESO` date NOT NULL,
  `EQ_FCREACION` date NOT NULL,
  `EQ_COSTO` float DEFAULT NULL,
  PRIMARY KEY (`EQ_IDEQUIPO`),
  UNIQUE KEY `EQ_MAC` (`EQ_MAC`),
  KEY `equipo_ubicacion` (`UB_IDUBICACION`),
  KEY `equipo_tipo` (`EQ_IDTIPO`),
  KEY `MAR_MARCA` (`EQ_MARCA`),
  KEY `EQ_MARCA` (`EQ_MARCA`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `equipo`
--

INSERT INTO `equipo` (`EQ_IDEQUIPO`, `UB_IDUBICACION`, `EQ_IDTIPO`, `EQ_NROEQUIPO`, `EQ_SERIEEQUIPO`, `EQ_MARCA`, `EQ_MODELO`, `EQ_RAM`, `EQ_DISCO`, `EQ_MAC`, `EQ_IP`, `EQ_PTAENLACE`, `EQ_MASCARA`, `EQ_PROCESADOR`, `EQ_ESTADO`, `EQ_FINGRESO`, `EQ_FCREACION`, `EQ_COSTO`) VALUES
(1, 1, 20, 1, 'PF082WK', 7, 'G40', 6, 160, '7E-EB-7D-C8-BF-2F', '192.168.0.2', '192.168.0.1', '255.255.0.0', 'QUADCORE-CELERON', 'reparacion', '2015-07-26', '2015-07-27', 160000),
(2, 1, 20, 2, '7E202238S', 2, 'L45', 4, 160, '6C-8B-5B-97-D6-E5', '192.168.0.3', '192.168.0.1', '255.255.0.0', 'DUALCORE-PENTIUM', 'activo', '2015-07-26', '2015-07-27', 200000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `impresion`
--
-- Creación: 28-10-2015 a las 18:34:53
--

CREATE TABLE IF NOT EXISTS `impresion` (
  `IM_IDIMPRESION` int(11) NOT NULL AUTO_INCREMENT,
  `TIP_IDTIPO` int(11) DEFAULT NULL,
  `UB_IDUBICACION` int(11) DEFAULT NULL,
  `IM_SERIEIMPRESION` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `IM_MARCA` int(11) NOT NULL,
  `IM_MODELO` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `IM_TIPOIMPRESION` char(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `IM_DESCRIPCION` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `IM_ESTADOIMP` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `IM_FEINGRESO` date NOT NULL,
  `IM_FCREACION` date NOT NULL,
  `IM_COSTO` int(11) NOT NULL,
  PRIMARY KEY (`IM_IDIMPRESION`),
  KEY `impresion_tipo` (`TIP_IDTIPO`),
  KEY `impresion_ubicacion` (`UB_IDUBICACION`),
  KEY `IM_MARCA` (`IM_MARCA`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `impresion`
--

INSERT INTO `impresion` (`IM_IDIMPRESION`, `TIP_IDTIPO`, `UB_IDUBICACION`, `IM_SERIEIMPRESION`, `IM_MARCA`, `IM_MODELO`, `IM_TIPOIMPRESION`, `IM_DESCRIPCION`, `IM_ESTADOIMP`, `IM_FEINGRESO`, `IM_FCREACION`, `IM_COSTO`) VALUES
(1, 7, 7, 'S4XY052127', 8, 'GENERICO', 'INYECCION TINTA', '- IMPRESORA TODO EN UNO, COLOR GRIS', 'activo', '2015-07-27', '2015-07-27', 125000),
(4, 1, 1, 'S4XY052127', 9, 'L555', 'MULTITONER', '- MULTITONER, MULTIFUNCION', 'activo', '2015-07-25', '2015-07-27', 250000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `insumos`
--
-- Creación: 28-10-2015 a las 18:34:53
--

CREATE TABLE IF NOT EXISTS `insumos` (
  `INS_IDINSUMO` int(11) NOT NULL AUTO_INCREMENT,
  `INS_CODIGO` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `INS_NBINSUMO` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `INS_DETALLE` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `INS_FCREACION` date NOT NULL,
  `INS_COSTOINSUMO` double DEFAULT NULL,
  PRIMARY KEY (`INS_IDINSUMO`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `insumos`
--

INSERT INTO `insumos` (`INS_IDINSUMO`, `INS_CODIGO`, `INS_NBINSUMO`, `INS_DETALLE`, `INS_FCREACION`, `INS_COSTOINSUMO`) VALUES
(1, ' 01', 'alicate', '- alicate rj45', '2015-07-27', 12000),
(2, '02', 'patch cord', '- cable de red', '2015-07-27', 15000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `licencia`
--
-- Creación: 28-10-2015 a las 18:34:54
--

CREATE TABLE IF NOT EXISTS `licencia` (
  `LIC_IDLICENCIA` int(11) NOT NULL AUTO_INCREMENT,
  `SOF_IDSOFTW` int(11) DEFAULT NULL,
  `LIC_NROLICENCIA` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `LIC_FCOMPRALIC` date DEFAULT NULL,
  `LIC_TIPOLICENCIA` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `LIC_FVENCIMIENTO` date DEFAULT NULL,
  `LIC_FINGRESO` date NOT NULL,
  `LIC_FCREACION` date NOT NULL,
  `LIC_SERIELICENCIA` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `LIC_USUARIOLIC` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `LIC_CORREOASOCIADO` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`LIC_IDLICENCIA`),
  KEY `licencia_software` (`SOF_IDSOFTW`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `licencia`
--

INSERT INTO `licencia` (`LIC_IDLICENCIA`, `SOF_IDSOFTW`, `LIC_NROLICENCIA`, `LIC_FCOMPRALIC`, `LIC_TIPOLICENCIA`, `LIC_FVENCIMIENTO`, `LIC_FINGRESO`, `LIC_FCREACION`, `LIC_SERIELICENCIA`, `LIC_USUARIOLIC`, `LIC_CORREOASOCIADO`) VALUES
(1, 1, ' V2C47-MK7JD-3R89F-D2KXW-VPK3J', '2015-07-20', 'PRIVATIVA', '2020-07-01', '2015-07-25', '2015-07-27', 'DEFGFFA2003', 'SALA', 'ESCUELA@WEB.CL'),
(2, 2, '9JBBv-7Q7P7-CTDB7-KYBKG-X8HHC ', '2015-07-11', 'PRIVATIVA', '2020-07-11', '2015-07-25', '2015-07-27', 'EDREF2014D', 'NO APLICA', 'COLEGIO@HOT.CL');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `log`
--
-- Creación: 28-10-2015 a las 18:34:54
--

CREATE TABLE IF NOT EXISTS `log` (
  `log_idlog` int(11) NOT NULL AUTO_INCREMENT,
  `log_fechalog` datetime NOT NULL,
  `log_iplog` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `log_observacion` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `log_idusuario` int(11) NOT NULL,
  PRIMARY KEY (`log_idlog`),
  KEY `log_usuario` (`log_idusuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=144 ;

--
-- Volcado de datos para la tabla `log`
--

INSERT INTO `log` (`log_idlog`, `log_fechalog`, `log_iplog`, `log_observacion`, `log_idusuario`) VALUES
(1, '2015-05-31 23:23:49', '127.0.0.1', 'Login de usuario', 2),
(2, '2015-05-31 23:24:46', '127.0.0.1', 'Login de usuario', 5),
(3, '2015-05-31 23:32:59', '127.0.0.1', 'Login de usuario', 5),
(4, '2015-05-31 23:37:38', '127.0.0.1', 'Login de usuario', 5),
(5, '2015-05-31 23:37:49', '127.0.0.1', 'Login de usuario', 2),
(6, '2015-05-31 23:38:07', '127.0.0.1', 'Login de usuario', 2),
(7, '2015-05-31 23:38:16', '127.0.0.1', 'Login de usuario', 5),
(8, '2015-06-01 00:15:25', '127.0.0.1', 'Login de usuario', 2),
(9, '2015-06-01 00:16:24', '127.0.0.1', 'Login de usuario', 2),
(10, '2015-06-01 00:16:42', '127.0.0.1', 'Login de usuario', 5),
(11, '2015-06-01 00:23:11', '127.0.0.1', 'Login de usuario', 2),
(12, '2015-06-01 00:37:50', '127.0.0.1', 'Login de usuario', 5),
(13, '2015-06-01 00:40:00', '127.0.0.1', 'Login de usuario', 5),
(14, '2015-06-01 00:44:36', '127.0.0.1', 'Login de usuario', 5),
(15, '2015-06-01 00:45:12', '127.0.0.1', 'Login de usuario', 5),
(16, '2015-06-01 00:45:27', '127.0.0.1', 'Login de usuario', 2),
(17, '2015-06-01 00:46:58', '127.0.0.1', 'Login de usuario', 5),
(18, '2015-06-01 00:50:05', '127.0.0.1', 'Login de usuario', 2),
(19, '2015-06-01 01:08:51', '127.0.0.1', 'Login de usuario', 5),
(20, '2015-06-01 01:12:48', '127.0.0.1', 'Login de usuario', 2),
(21, '2015-06-01 01:23:57', '127.0.0.1', 'Login de usuario', 4),
(22, '2015-06-01 01:29:07', '127.0.0.1', 'Login de usuario', 4),
(23, '2015-06-01 01:32:23', '127.0.0.1', 'Login de usuario', 4),
(24, '2015-06-01 01:54:19', '127.0.0.1', 'Login de usuario', 3),
(25, '2015-06-01 23:33:41', '127.0.0.1', 'Login de usuario', 5),
(26, '2015-06-01 23:38:20', '127.0.0.1', 'Login de usuario', 2),
(27, '2015-06-01 23:38:37', '127.0.0.1', 'Login de usuario', 5),
(28, '2015-06-01 23:38:56', '127.0.0.1', 'Login de usuario', 3),
(29, '2015-06-03 12:21:59', '127.0.0.1', 'Login de usuario', 4),
(30, '2015-06-03 12:22:31', '127.0.0.1', 'Login de usuario', 5),
(31, '2015-06-03 12:34:58', '127.0.0.1', 'Login de usuario', 2),
(32, '2015-06-03 14:13:25', '127.0.0.1', 'Login de usuario', 2),
(33, '2015-06-03 15:30:32', '127.0.0.1', 'Login de usuario', 5),
(34, '2015-06-05 23:00:32', '127.0.0.1', 'Login de usuario', 2),
(35, '2015-06-06 19:39:30', '127.0.0.1', 'Login de usuario', 2),
(36, '2015-06-09 23:00:33', '127.0.0.1', 'Login de usuario', 2),
(37, '2015-06-12 01:05:16', '127.0.0.1', 'Login de usuario', 2),
(38, '2015-06-12 01:11:29', '127.0.0.1', 'Login de usuario', 2),
(39, '2015-06-12 01:15:11', '127.0.0.1', 'Login de usuario', 2),
(40, '2015-06-12 12:04:06', '127.0.0.1', 'Login de usuario', 2),
(41, '2015-06-12 12:18:56', '127.0.0.1', 'Login de usuario', 2),
(42, '2015-06-12 12:22:14', '127.0.0.1', 'Login de usuario', 2),
(43, '2015-06-12 12:54:15', '127.0.0.1', 'Login de usuario', 2),
(44, '2015-06-12 14:58:10', '127.0.0.1', 'Login de usuario', 2),
(45, '2015-06-12 14:59:47', '127.0.0.1', 'Login de usuario', 2),
(46, '2015-06-12 16:33:30', '127.0.0.1', 'Login de usuario', 2),
(47, '2015-06-20 00:15:56', '127.0.0.1', 'Login de usuario', 2),
(48, '2015-06-25 02:22:22', '127.0.0.1', 'Login de usuario', 2),
(49, '2015-06-25 22:51:06', '127.0.0.1', 'Login de usuario', 2),
(50, '2015-06-25 23:20:20', '127.0.0.1', 'Login de usuario', 2),
(51, '2015-06-25 23:42:37', '127.0.0.1', 'Login de usuario', 2),
(52, '2015-06-26 01:00:27', '127.0.0.1', 'Login de usuario', 2),
(53, '2015-06-26 02:36:48', '127.0.0.1', 'Login de usuario', 2),
(54, '2015-06-26 12:54:16', '127.0.0.1', 'Login de usuario', 2),
(55, '2015-06-26 18:37:45', '127.0.0.1', 'Login de usuario', 2),
(56, '2015-06-26 19:59:44', '127.0.0.1', 'Login de usuario', 2),
(57, '2015-06-26 20:01:20', '127.0.0.1', 'Login de usuario', 2),
(58, '2015-06-26 21:29:17', '127.0.0.1', 'Login de usuario', 2),
(59, '2015-06-27 02:23:50', '127.0.0.1', 'Login de usuario', 2),
(60, '2015-06-27 02:27:57', '127.0.0.1', 'Login de usuario', 2),
(61, '2015-06-27 11:03:06', '127.0.0.1', 'Login de usuario', 2),
(62, '2015-06-27 11:28:58', '127.0.0.1', 'Login de usuario', 2),
(63, '2015-06-27 16:14:46', '127.0.0.1', 'Login de usuario', 2),
(64, '2015-06-28 17:20:24', '127.0.0.1', 'Login de usuario', 2),
(65, '2015-06-29 12:21:15', '127.0.0.1', 'Login de usuario', 2),
(66, '2015-06-29 17:45:31', '127.0.0.1', 'Login de usuario', 2),
(67, '2015-06-29 17:50:05', '127.0.0.1', 'Login de usuario', 2),
(68, '2015-06-29 23:54:00', '127.0.0.1', 'Login de usuario', 2),
(69, '2015-06-30 00:13:35', '127.0.0.1', 'Login de usuario', 2),
(70, '2015-06-30 01:22:26', '127.0.0.1', 'Login de usuario', 2),
(71, '2015-06-30 20:40:13', '127.0.0.1', 'Login de usuario', 2),
(72, '2015-07-01 00:37:41', '127.0.0.1', 'Login de usuario', 7),
(73, '2015-07-01 00:48:28', '127.0.0.1', 'Login de usuario', 2),
(74, '2015-07-01 01:20:32', '127.0.0.1', 'Login de usuario', 2),
(75, '2015-07-01 02:26:16', '127.0.0.1', 'Login de usuario', 2),
(76, '2015-07-01 15:19:30', '127.0.0.1', 'Login de usuario', 2),
(77, '2015-07-01 17:08:11', '127.0.0.1', 'Login de usuario', 2),
(78, '2015-07-01 20:08:49', '127.0.0.1', 'Login de usuario', 2),
(79, '2015-07-01 22:13:02', '127.0.0.1', 'Login de usuario', 2),
(80, '2015-07-02 03:28:01', '127.0.0.1', 'Login de usuario', 2),
(81, '2015-07-02 03:54:53', '127.0.0.1', 'Login de usuario', 2),
(82, '2015-07-02 14:31:06', '127.0.0.1', 'Login de usuario', 2),
(83, '2015-07-02 15:21:10', '127.0.0.1', 'Login de usuario', 5),
(84, '2015-07-02 15:33:07', '127.0.0.1', 'Login de usuario', 2),
(85, '2015-07-02 22:48:28', '127.0.0.1', 'Login de usuario', 2),
(86, '2015-07-03 01:37:20', '127.0.0.1', 'Login de usuario', 2),
(87, '2015-07-03 02:02:48', '127.0.0.1', 'Login de usuario', 2),
(88, '2015-07-03 12:34:34', '127.0.0.1', 'Login de usuario', 2),
(89, '2015-07-04 01:50:54', '127.0.0.1', 'Login de usuario', 2),
(90, '2015-07-05 22:26:02', '127.0.0.1', 'Login de usuario', 2),
(91, '2015-07-06 16:27:00', '127.0.0.1', 'Login de usuario', 2),
(92, '2015-07-06 19:03:10', '127.0.0.1', 'Login de usuario', 2),
(93, '2015-07-09 01:16:10', '127.0.0.1', 'Login de usuario', 2),
(94, '2015-07-09 01:20:46', '127.0.0.1', 'Login de usuario', 2),
(95, '2015-07-09 01:21:06', '127.0.0.1', 'Login de usuario', 2),
(96, '2015-07-09 03:13:40', '127.0.0.1', 'login de usuario', 2),
(97, '2015-07-09 03:14:26', '127.0.0.1', 'login de usuario', 2),
(98, '2015-07-09 03:14:32', '127.0.0.1', 'login de usuario', 2),
(99, '2015-07-09 03:15:03', '127.0.0.1', 'login de usuario', 2),
(100, '2015-07-09 03:16:43', '127.0.0.1', 'login de usuario', 2),
(101, '2015-07-09 19:50:14', '127.0.0.1', 'login de usuario', 2),
(102, '2015-07-09 21:47:52', '127.0.0.1', 'login de usuario', 2),
(103, '2015-07-09 23:39:38', '127.0.0.1', 'login de usuario', 2),
(104, '2015-07-09 23:46:56', '127.0.0.1', 'login de usuario', 2),
(105, '2015-07-10 00:52:58', '127.0.0.1', 'login de usuario', 2),
(106, '2015-07-10 02:14:07', '127.0.0.1', 'login de usuario', 2),
(107, '2015-07-10 02:26:42', '127.0.0.1', 'login de usuario', 2),
(108, '2015-07-10 02:38:39', '127.0.0.1', 'login de usuario', 2),
(109, '2015-07-10 18:29:54', '127.0.0.1', 'login de usuario', 2),
(110, '2015-07-10 18:30:50', '127.0.0.1', 'login de usuario', 2),
(111, '2015-07-13 23:31:55', '127.0.0.1', 'login de usuario', 2),
(112, '2015-07-14 02:20:23', '127.0.0.1', 'login de usuario', 2),
(113, '2015-07-14 16:16:40', '127.0.0.1', 'login de usuario', 2),
(114, '2015-07-14 18:25:51', '127.0.0.1', 'login de usuario', 2),
(115, '2015-07-15 01:30:43', '127.0.0.1', 'login de usuario', 5),
(116, '2015-07-15 03:46:17', '127.0.0.1', 'login de usuario', 5),
(117, '2015-07-15 04:00:26', '127.0.0.1', 'login de usuario', 2),
(118, '2015-07-15 04:01:19', '127.0.0.1', 'login de usuario', 2),
(119, '2015-07-15 14:24:44', '127.0.0.1', 'login de usuario', 2),
(120, '2015-07-15 14:28:12', '127.0.0.1', 'login de usuario', 2),
(121, '2015-07-15 14:53:17', '127.0.0.1', 'login de usuario', 2),
(122, '2015-07-15 19:14:54', '127.0.0.1', 'login de usuario', 2),
(123, '2015-07-15 19:34:10', '127.0.0.1', 'login de usuario', 2),
(124, '2015-07-17 16:05:15', '127.0.0.1', 'login de usuario', 2),
(125, '2015-07-20 22:05:41', '127.0.0.1', 'login de usuario', 2),
(126, '2015-07-21 16:34:03', '127.0.0.1', 'login de usuario', 2),
(127, '2015-07-21 22:16:16', '127.0.0.1', 'login de usuario', 2),
(128, '2015-07-25 22:02:07', '127.0.0.1', 'login de usuario', 2),
(129, '2015-07-25 22:44:09', '127.0.0.1', 'login de usuario', 2),
(130, '2015-07-26 10:47:07', '127.0.0.1', 'login de usuario', 2),
(131, '2015-07-26 15:37:40', '127.0.0.1', 'login de usuario', 2),
(132, '2015-07-27 14:13:15', '127.0.0.1', 'login de usuario', 2),
(133, '2015-07-27 14:54:58', '127.0.0.1', 'login de usuario', 2),
(134, '2015-07-27 16:12:07', '127.0.0.1', 'login de usuario', 2),
(135, '2015-07-27 16:15:19', '127.0.0.1', 'login de usuario', 5),
(136, '2015-07-29 12:23:50', '127.0.0.1', 'login de usuario', 2),
(137, '2015-07-30 21:22:54', '127.0.0.1', 'login de usuario', 2),
(138, '2015-08-02 12:15:53', '127.0.0.1', 'login de usuario', 2),
(139, '2015-08-02 12:36:04', '127.0.0.1', 'login de usuario', 2),
(140, '2015-11-12 13:56:52', '127.0.0.1', 'login de usuario', 2),
(141, '2015-11-12 15:22:46', '127.0.0.1', 'login de usuario', 2),
(142, '2015-11-12 15:32:44', '127.0.0.1', 'login de usuario', 2),
(143, '2015-11-12 15:43:54', '127.0.0.1', 'login de usuario', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marca`
--
-- Creación: 28-10-2015 a las 18:34:54
--

CREATE TABLE IF NOT EXISTS `marca` (
  `MAR_IDMARCA` int(11) NOT NULL AUTO_INCREMENT,
  `MAR_NBMARCA` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `MAR_OBSERVACION` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `MAR_FCREACION` date NOT NULL,
  PRIMARY KEY (`MAR_IDMARCA`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=15 ;

--
-- Volcado de datos para la tabla `marca`
--

INSERT INTO `marca` (`MAR_IDMARCA`, `MAR_NBMARCA`, `MAR_OBSERVACION`, `MAR_FCREACION`) VALUES
(2, 'TOSHIBA', 'MARCA JAPONESA', '2015-07-26'),
(3, 'ACER', 'MARCA JAPONESA', '2015-07-26'),
(4, 'HP', 'MARCA AMERICANA', '2015-07-26'),
(5, 'SAMSUNG', 'MARCA KOREANA', '2015-07-26'),
(6, 'OLIDATA', 'MARCA CHINA', '2015-07-26'),
(7, 'LENOVO', 'MARCA CHINA', '2015-07-26'),
(8, 'EPSON', 'MARCA EUROPEA', '2015-07-26'),
(9, 'BROTHER', 'MARCA AMERICANA', '2015-07-26'),
(10, 'D-LINK', '- MARCA REDES', '2015-07-27'),
(11, 'MICRO-TREND', '- MARCA RED', '2015-07-27'),
(12, 'ZYXEL', '-MARCA ROUTER', '2015-07-27'),
(13, 'LINKSYS', '-MARCA ROUTER WIFI', '2015-07-27'),
(14, 'CISCO', '-MARCA SWITCH', '2015-07-27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil`
--
-- Creación: 28-10-2015 a las 18:34:54
--

CREATE TABLE IF NOT EXISTS `perfil` (
  `perf_idperfil` int(11) NOT NULL AUTO_INCREMENT,
  `perf_nbperfil` varchar(50) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `perf_modulo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `perf_fcreacion` datetime NOT NULL,
  `perf_observacion` varchar(100) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`perf_idperfil`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `perfil`
--

INSERT INTO `perfil` (`perf_idperfil`, `perf_nbperfil`, `perf_modulo`, `perf_fcreacion`, `perf_observacion`) VALUES
(1, 'administrador', 'inventario', '2015-05-31 00:00:00', 'creado para pruebas en sistema'),
(3, 'administrador', 'academico', '2015-05-31 00:00:00', 'creado para pruebas en el sistema'),
(4, 'visualizador', 'academico', '2015-05-31 00:00:00', 'creado para pruebas en el sistema'),
(7, 'visualizador', 'inventario', '2015-05-31 00:00:00', 'creado para pruebas en el sistema');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `periferico`
--
-- Creación: 28-10-2015 a las 18:34:54
--

CREATE TABLE IF NOT EXISTS `periferico` (
  `PER_IDPERIFERICO` int(11) NOT NULL AUTO_INCREMENT,
  `EQ_IDEQUIPO` int(11) DEFAULT NULL,
  `TIP_IDTIPO` int(11) DEFAULT NULL,
  `PER_MARCAPERIFERICO` int(11) DEFAULT NULL,
  `PER_MODELO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `PER_SERIEPERIFERICO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `PER_COLORPERIFERICO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `PER_ESTADOPERIFERICO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `PER_COSTO` int(11) DEFAULT NULL,
  `PER_NROPERIFERICO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`PER_IDPERIFERICO`),
  KEY `periferico_equipo` (`EQ_IDEQUIPO`),
  KEY `periferico_tipo` (`TIP_IDTIPO`),
  KEY `PER_MARCAPERIFERICO` (`PER_MARCAPERIFERICO`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `periferico`
--

INSERT INTO `periferico` (`PER_IDPERIFERICO`, `EQ_IDEQUIPO`, `TIP_IDTIPO`, `PER_MARCAPERIFERICO`, `PER_MODELO`, `PER_SERIEPERIFERICO`, `PER_COLORPERIFERICO`, `PER_ESTADOPERIFERICO`, `PER_COSTO`, `PER_NROPERIFERICO`) VALUES
(1, 1, 13, 4, 'GENERICO', 'X3B82657301245', 'NEGRO', 'activo', 60000, '1'),
(2, 1, 24, 2, 'GENERICO', 'SIN SERIE', 'NEGRO', 'activo', 60000, '2'),
(3, 1, 16, 2, 'GENERICO', 'QTFG456665', 'NEGRO', 'activo', 10000, '3'),
(4, 2, 14, 3, 'GENERICO', 'SIN SERIE', 'ROJO', 'activo', 5000, '3'),
(5, 2, 18, 2, 'GENERICO', 'SIN SERIE', 'NEGRO', 'activo', 5000, '5'),
(6, 2, 25, 3, 'QT45778', 'SIN SERIE', 'NEGRO', 'activo', 60000, '6');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--
-- Creación: 28-10-2015 a las 18:34:54
--

CREATE TABLE IF NOT EXISTS `persona` (
  `pers_idpersona` int(11) NOT NULL AUTO_INCREMENT,
  `pers_nbpersona` varchar(60) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `pers_apppersona` varchar(60) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `pers_dirpersona` varchar(100) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `pers_rutpersona` varchar(40) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`pers_idpersona`),
  UNIQUE KEY `persona_rut` (`pers_rutpersona`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=14 ;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`pers_idpersona`, `pers_nbpersona`, `pers_apppersona`, `pers_dirpersona`, `pers_rutpersona`) VALUES
(1, 'juan pablo', 'munoz leiva', 'los olivos 11145', '16.137.272-2'),
(2, 'maria luisa ', 'leiva carvallo', 'juan antonio rios 1145', '7.968.343-4'),
(3, 'mario orlando', 'muÃƒÂ±oz perez', 'la tirana 1134, iquique', '5.755.785-1'),
(4, 'paola angelica', 'fuentes martinez', 'luis cruchaga 3340', '14.392.813-6'),
(13, 'ronald osvaldo', 'carrasco acevedo', '- calle 2, casa 705,pob.bdo ohiggins, chgte', '15.944.288-2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `red`
--
-- Creación: 28-10-2015 a las 18:34:54
--

CREATE TABLE IF NOT EXISTS `red` (
  `RED_IDRED` int(11) NOT NULL AUTO_INCREMENT,
  `TIP_IDTIPO` int(11) DEFAULT NULL,
  `UB_IDUBICACION` int(11) DEFAULT NULL,
  `RED_MARCAEQUIPO` int(11) DEFAULT NULL,
  `RED_MODELO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `RED_SERIERED` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `RED_TIPOEQUIPO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `RED_ESTADO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `RED_MACEQUIPO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `RED_NROBOCAS` smallint(6) DEFAULT NULL,
  `RED_IPINICIAL` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `RED_PTAENLACE` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `RED_MASCARA` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `RED_USUARIO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `RED_CLAVE` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `RED_FINGRESO` date NOT NULL,
  `RED_FCREACION` date NOT NULL,
  `RED_COSTO` float NOT NULL,
  PRIMARY KEY (`RED_IDRED`),
  UNIQUE KEY `RED_MACEQUIPO` (`RED_MACEQUIPO`),
  KEY `red_tipo` (`TIP_IDTIPO`),
  KEY `red_ubicacion` (`UB_IDUBICACION`),
  KEY `RED_MARCAEQUIPO` (`RED_MARCAEQUIPO`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `red`
--

INSERT INTO `red` (`RED_IDRED`, `TIP_IDTIPO`, `UB_IDUBICACION`, `RED_MARCAEQUIPO`, `RED_MODELO`, `RED_SERIERED`, `RED_TIPOEQUIPO`, `RED_ESTADO`, `RED_MACEQUIPO`, `RED_NROBOCAS`, `RED_IPINICIAL`, `RED_PTAENLACE`, `RED_MASCARA`, `RED_USUARIO`, `RED_CLAVE`, `RED_FINGRESO`, `RED_FCREACION`, `RED_COSTO`) VALUES
(1, 12, 3, 12, 'QT-456', 'DEFG-45GH', '8', 'activo', '25-06-C6-87-F1-AA', 6, '192.168.0.10', '192.168.0.1', '255.255.0.0', 'NO APLICA', 'NO APLICA', '2015-07-25', '2015-07-27', 25000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `software`
--
-- Creación: 28-10-2015 a las 18:34:54
--

CREATE TABLE IF NOT EXISTS `software` (
  `SOF_IDSOFTW` int(11) NOT NULL AUTO_INCREMENT,
  `EQ_IDEQUIPO` int(11) DEFAULT NULL,
  `SOF_NBSOFTW` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `SOFT_TIPOSOFTW` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `SOFT_ARQUITEC` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `SOFT_EMPRESA` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `SOFT_ACTIVADO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `SOFT_ANOVERS` date NOT NULL,
  `SOF_FCREACION` date NOT NULL,
  `SOFT_VERSION` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `SOFT_WEBSOFT` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`SOF_IDSOFTW`),
  KEY `software_equipo` (`EQ_IDEQUIPO`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `software`
--

INSERT INTO `software` (`SOF_IDSOFTW`, `EQ_IDEQUIPO`, `SOF_NBSOFTW`, `SOFT_TIPOSOFTW`, `SOFT_ARQUITEC`, `SOFT_EMPRESA`, `SOFT_ACTIVADO`, `SOFT_ANOVERS`, `SOF_FCREACION`, `SOFT_VERSION`, `SOFT_WEBSOFT`) VALUES
(1, 1, 'WINDOWS XP', 'sistema operativo', '64bits', 'MICROSOFT', 'activo', '2003-01-01', '2015-07-27', '1.0.0', 'www.microsoft.cl'),
(2, 2, 'WINDOWS 7', 'sistema operativo', '64bits', 'MICROSOFT', 'activo', '2014-01-01', '2015-07-27', '2.0.0.0', 'www.microsoft.cl');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `taller`
--
-- Creación: 28-10-2015 a las 18:34:55
--

CREATE TABLE IF NOT EXISTS `taller` (
  `TA_IDTALLER` int(11) NOT NULL AUTO_INCREMENT,
  `EQ_IDEQUIPO` int(11) DEFAULT NULL,
  `IM_IDIMPRESION` int(11) DEFAULT NULL,
  `TA_IDRED` int(11) DEFAULT NULL,
  `TA_IDUSUARIO` int(11) DEFAULT NULL,
  `TA_FCREACION` datetime DEFAULT NULL,
  `TA_FEJECUCION` datetime DEFAULT NULL COMMENT 'EJECUCION O CIERRE',
  `TA_DESCTALLER` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `TA_MOTIVO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `TA_DEFECTO` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `TA_DIAGNOSTICO` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `TA_ESTADO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  `TA_GLOSAFINAL` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `TA_ESTADOFINALREP` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`TA_IDTALLER`),
  KEY `FK_IMPRESORA_A_TALLER` (`IM_IDIMPRESION`),
  KEY `FK_PUEDE_ESTAR_MAS_DE_UNA_VEZ` (`EQ_IDEQUIPO`),
  KEY `TA_IDRED` (`TA_IDRED`),
  KEY `TA_IDUSUARIO` (`TA_IDUSUARIO`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `taller`
--

INSERT INTO `taller` (`TA_IDTALLER`, `EQ_IDEQUIPO`, `IM_IDIMPRESION`, `TA_IDRED`, `TA_IDUSUARIO`, `TA_FCREACION`, `TA_FEJECUCION`, `TA_DESCTALLER`, `TA_MOTIVO`, `TA_DEFECTO`, `TA_DIAGNOSTICO`, `TA_ESTADO`, `TA_GLOSAFINAL`, `TA_ESTADOFINALREP`) VALUES
(1, 1, NULL, NULL, 2, '2015-07-27 14:18:59', '2015-07-27 14:21:57', '- falla en conector de red', 'orden', 'conector malo, pata', '- por tiron de cable, se requiere cable patch y crimpeador', 'finalizado', '    - se compran materiales     \r\n          ', 'no reparado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo`
--
-- Creación: 28-10-2015 a las 18:34:55
--

CREATE TABLE IF NOT EXISTS `tipo` (
  `TIP_IDTIPO` int(11) NOT NULL AUTO_INCREMENT,
  `TIP_NBTIPO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `TIPO_DESCTIPO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`TIP_IDTIPO`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=26 ;

--
-- Volcado de datos para la tabla `tipo`
--

INSERT INTO `tipo` (`TIP_IDTIPO`, `TIP_NBTIPO`, `TIPO_DESCTIPO`) VALUES
(1, 'IMPRESORA ', '- IMPRESORA H&O'),
(2, 'IMPRESORA LASER', '- USO H&O'),
(3, 'IMPRESORA IMPACTO', '- USO FISCAL, OFFICE'),
(4, 'IMPRESORA INYECCION', '- USO H&O'),
(5, 'IMPRESORA TERMICA', '- USO FISCAL, COMERCIO'),
(6, 'IMPRESORA MULTIF', '-SCANNER, FOTO, IMPRESION'),
(7, 'ROUTER ', '- USO H&O'),
(8, 'ROUTER ADSL', '- USO H&O'),
(9, 'SWITCH GENERICO', '- SWITCH S/CONFIGURACION'),
(10, 'SWITCH CONF', 'SWITCH C/CONF'),
(11, 'MODEM ADSL', '-MODEM USO H&O '),
(12, 'HUB', '- CONECTOR PUENTE'),
(13, 'MOUSE BOLITA', '- MOUSE USO H&O'),
(14, 'MOUSE LASER', '- MOUSE USO H&O'),
(15, 'MOUSE IR', '- MOUSE INFRARROJO'),
(16, 'TECLADO PS2', '- TECLADO GENERICO'),
(17, 'TECLADO PS1', '- TECLADO ANTIGUO '),
(18, 'TECLADO USB', '-TECLADO ESTANDAR'),
(19, 'TECLADO BLUETOOTH', '- TECLADO WIRELESS'),
(20, 'NOTEBOOK GENERICO', '- NOTEBOOK 14-15"'),
(21, 'NETBOOK', '- NOTEBOOK MINIMIZADO'),
(22, 'ALL IN ONE', '-EQUIPO TODO EN UNO'),
(23, 'PC ESCRITORIO', '-TORRE NORMAL'),
(24, 'MONITOR LCD', '- MONITOR GENERICO TFT'),
(25, 'MONITOR LED', '- MONITOR LCD, LED');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicacion`
--
-- Creación: 28-10-2015 a las 18:34:55
--

CREATE TABLE IF NOT EXISTS `ubicacion` (
  `UB_IDUBICACION` int(11) NOT NULL AUTO_INCREMENT,
  `UB_NROSALA` tinyint(4) DEFAULT NULL,
  `UB_PISOSALA` tinyint(4) DEFAULT NULL,
  `UB_TIPOSALA` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`UB_IDUBICACION`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `ubicacion`
--

INSERT INTO `ubicacion` (`UB_IDUBICACION`, `UB_NROSALA`, `UB_PISOSALA`, `UB_TIPOSALA`) VALUES
(1, 1, 1, 'clases'),
(2, 2, 1, ' clases'),
(3, 3, 1, ' clases'),
(4, 4, 1, 'profesores'),
(5, 5, 2, 'taller multiproposito'),
(6, 6, 2, 'biblioteca'),
(7, 7, 2, 'bodega');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--
-- Creación: 28-10-2015 a las 18:34:55
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `usu_idusuario` int(11) NOT NULL AUTO_INCREMENT,
  `usu_nbusuario` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `usu_correousuario` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `usu_passusuario` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `usu_fcreacion` datetime NOT NULL,
  `usu_observacion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `usu_idpersona` int(11) DEFAULT NULL,
  `usu_idperfil` int(11) DEFAULT NULL,
  PRIMARY KEY (`usu_idusuario`),
  KEY `usuario_persona` (`usu_idpersona`),
  KEY `usu_idperfil` (`usu_idperfil`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`usu_idusuario`, `usu_nbusuario`, `usu_correousuario`, `usu_passusuario`, `usu_fcreacion`, `usu_observacion`, `usu_idpersona`, `usu_idperfil`) VALUES
(2, 'ZW1wb3dkZXJlZA==', 'juanp.mleiva@gmail.com', 'anBtbDEyMzQ1Ng==', '2015-05-30 00:00:00', 'creado como pruebas', 1, 1),
(3, 'a2FpZ28=', 'kaigo@hotmail.com', 'anBtbDEyMw==', '2015-05-31 06:08:00', 'producto presente', 2, 3),
(4, 'a2FpZ28y', 'kaigo@hotmail.com', 'anBtbDEyMw==', '2015-05-31 00:00:00', 'creado para pruebas', 3, 4),
(5, 'cGp1YW40NDQ=', 'pjuan444@gmail.com', 'anBtbDEyMw==', '2015-05-31 00:00:00', 'usuario creado para pruebas', 4, 7),
(7, 'a2Fzdmplbg==', 'kasvjen@gmail.com', 'a2Fzdmplbg==', '2015-07-01 00:35:57', '- usuario de prueba', 13, 1);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalle`
--
ALTER TABLE `detalle`
  ADD CONSTRAINT `detalle_ibfk_1` FOREIGN KEY (`TA_IDTALLER`) REFERENCES `taller` (`TA_IDTALLER`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `detalle_ibfk_2` FOREIGN KEY (`DET_IDINSUMO`) REFERENCES `insumos` (`INS_IDINSUMO`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `equipo`
--
ALTER TABLE `equipo`
  ADD CONSTRAINT `equipo_ibfk_1` FOREIGN KEY (`UB_IDUBICACION`) REFERENCES `ubicacion` (`UB_IDUBICACION`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `equipo_ibfk_2` FOREIGN KEY (`EQ_IDTIPO`) REFERENCES `tipo` (`TIP_IDTIPO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `equipo_ibfk_3` FOREIGN KEY (`EQ_MARCA`) REFERENCES `marca` (`MAR_IDMARCA`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `impresion`
--
ALTER TABLE `impresion`
  ADD CONSTRAINT `impresion_ibfk_1` FOREIGN KEY (`TIP_IDTIPO`) REFERENCES `tipo` (`TIP_IDTIPO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `impresion_ibfk_2` FOREIGN KEY (`UB_IDUBICACION`) REFERENCES `ubicacion` (`UB_IDUBICACION`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `impresion_ibfk_3` FOREIGN KEY (`IM_MARCA`) REFERENCES `marca` (`MAR_IDMARCA`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `licencia`
--
ALTER TABLE `licencia`
  ADD CONSTRAINT `licencia_ibfk_1` FOREIGN KEY (`SOF_IDSOFTW`) REFERENCES `software` (`SOF_IDSOFTW`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `fk_log_usuario1` FOREIGN KEY (`log_idusuario`) REFERENCES `usuario` (`usu_idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `periferico`
--
ALTER TABLE `periferico`
  ADD CONSTRAINT `periferico_ibfk_1` FOREIGN KEY (`TIP_IDTIPO`) REFERENCES `tipo` (`TIP_IDTIPO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `periferico_ibfk_2` FOREIGN KEY (`EQ_IDEQUIPO`) REFERENCES `equipo` (`EQ_IDEQUIPO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `periferico_ibfk_3` FOREIGN KEY (`PER_MARCAPERIFERICO`) REFERENCES `marca` (`MAR_IDMARCA`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `red`
--
ALTER TABLE `red`
  ADD CONSTRAINT `red_ibfk_1` FOREIGN KEY (`TIP_IDTIPO`) REFERENCES `tipo` (`TIP_IDTIPO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `red_ibfk_2` FOREIGN KEY (`UB_IDUBICACION`) REFERENCES `ubicacion` (`UB_IDUBICACION`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `red_ibfk_3` FOREIGN KEY (`RED_MARCAEQUIPO`) REFERENCES `marca` (`MAR_IDMARCA`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `software`
--
ALTER TABLE `software`
  ADD CONSTRAINT `software_ibfk_1` FOREIGN KEY (`EQ_IDEQUIPO`) REFERENCES `equipo` (`EQ_IDEQUIPO`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `taller`
--
ALTER TABLE `taller`
  ADD CONSTRAINT `taller_ibfk_1` FOREIGN KEY (`EQ_IDEQUIPO`) REFERENCES `equipo` (`EQ_IDEQUIPO`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `taller_ibfk_2` FOREIGN KEY (`IM_IDIMPRESION`) REFERENCES `impresion` (`IM_IDIMPRESION`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `taller_ibfk_3` FOREIGN KEY (`TA_IDRED`) REFERENCES `red` (`RED_IDRED`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `taller_ibfk_4` FOREIGN KEY (`TA_IDUSUARIO`) REFERENCES `usuario` (`usu_idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `fk_usuario_perfil` FOREIGN KEY (`usu_idperfil`) REFERENCES `perfil` (`perf_idperfil`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_usuario_persona` FOREIGN KEY (`usu_idpersona`) REFERENCES `persona` (`pers_idpersona`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
